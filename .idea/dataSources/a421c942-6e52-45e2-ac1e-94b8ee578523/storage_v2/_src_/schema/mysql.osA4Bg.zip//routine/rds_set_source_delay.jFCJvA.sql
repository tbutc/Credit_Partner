create
    definer = rdsadmin@localhost procedure rds_set_source_delay(IN delay int)
BEGIN
  DECLARE v_mysql_version VARCHAR(20);
  DECLARE v_called_by_user VARCHAR(352);
  DECLARE sql_logging BOOLEAN;
  IF delay IS NULL OR delay NOT BETWEEN 0 AND 86400 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'For source delay the value must be between 0 and 86400 inclusive.';
  END IF;
  SELECT @@sql_log_bin, user(), version() INTO sql_logging, v_called_by_user, v_mysql_version;
  
  BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN SET @@sql_log_bin=sql_logging; RESIGNAL; END;
    SET @@sql_log_bin=OFF;
    
    SET @cmd = CONCAT('CHANGE REPLICATION SOURCE TO SOURCE_DELAY = ', delay);
    PREPARE rds_set_delay FROM @cmd;
    EXECUTE rds_set_delay;
    DEALLOCATE PREPARE rds_set_delay;
    UPDATE mysql.rds_configuration SET value = delay WHERE name = 'source delay';
    COMMIT;
    INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_delay)
    VALUES(v_called_by_user, 'set source delay', v_mysql_version, delay);
    COMMIT;
    SELECT 'source delay is set successfully.' AS Message;
    SET @@sql_log_bin=sql_logging;
  END;
END;

