create definer = rdsadmin@localhost view rds_reserved_users as
(select `mysql`.`user`.`User` AS `user`, 'localhost' AS `host`, 'RDS management user' AS `description`
 from `mysql`.`user`
 where (`mysql`.`user`.`User` = 'rdsadmin')
 limit 1)
union all
(select `mysql`.`user`.`User` AS `user`, '%' AS `host`, 'RDS replication user' AS `description`
 from `mysql`.`user`
 where (`mysql`.`user`.`User` = 'rdsrepladmin')
 limit 1)
union all
select `mysql`.`user`.`User` AS `user`, '%' AS `host`, 'RDS multi-AZ topology manager' AS `description`
from `mysql`.`user`
where ((`mysql`.`user`.`User` = 'rdstopmgr') and (`rds_is_semi_sync`() <> 'NO'));

