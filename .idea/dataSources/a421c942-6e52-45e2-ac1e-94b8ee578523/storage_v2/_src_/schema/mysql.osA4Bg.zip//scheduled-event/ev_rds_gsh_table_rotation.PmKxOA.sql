create definer = rdsadmin@localhost event ev_rds_gsh_table_rotation on schedule
    every '7' DAY
        starts '2023-08-05 06:01:18'
    on completion preserve
    disable
    do
    CALL rds_rotate_global_status_history();

