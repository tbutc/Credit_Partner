create definer = rdsadmin@localhost event ev_rds_gsh_collector on schedule
    every '5' MINUTE
        starts '2023-07-29 06:01:18'
    on completion preserve
    disable
    do
    CALL rds_collect_global_status_history();

